import React, { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import FoodItemList from "./FoodItemList";

export default function FoodItemsSmall(props) {
 
  const foods = [
    {
      id: 1,
      name: "Chicken Biriyani",
      price: 350,
      
      category_name: "LAMB DISHES",
      img:"https://i.pinimg.com/564x/67/70/6c/67706c77822f159cf28e203ebdc0cfd6.jpg"
    },
    {
      id: 2,
      name: "Noodles",
      price: 199,
      
      category_name: "SOUP",
      img:"https://i.pinimg.com/564x/67/70/6c/67706c77822f159cf28e203ebdc0cfd6.jpg"
    },
    {
      id: 3,
      name: "Alfam",
      price: 100,
    
      category_name: "INDIAN CHAATS",
      img:"https://i.pinimg.com/564x/67/70/6c/67706c77822f159cf28e203ebdc0cfd6.jpg"
    },
  ];



  return (
    <>
   
     <div>
      { props.categories ? props.categories.map( (cat,index) => { 

     return(
      <div>
      <Card.Title className="heading-color">{cat.catnameeng}</Card.Title> 
      {/* <FoodItemList  food={food}/> */}
      {props.foods.filter(food => food.category_id === cat.id).map(food_items => (
       <div>
          {/* {filteredPerson.name} */}
          <FoodItemList  food={food_items}/>
       </div>
      ))}

      </div>
      )

     
      
      }) :"" 

      }
     </div>
    </>
  );
}
